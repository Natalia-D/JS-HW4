'use strict';

const BasePage = require("./BasePage");

class CareersPage extends BasePage{
	constructor (){
		super();

        this.Page = element(by.css('.et_builder_inner_content'));
		this.AnySpecialty =  element(by.xpath('//div[@id="specialty_select"]'));
        this.AllLocations =  element(by.xpath('//div[@id="locations_select"]'));

		       
	};
}

module.exports = CareersPage;