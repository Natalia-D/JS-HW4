const { browser } = require('protractor');
const CareersPage = require('../../po/pages/CareersPage');
const HomePage = require('../../po/pages/HomePage');
const careersPage = new CareersPage()
const homePage = new HomePage()

describe("Careers ", () => {
   
    beforeAll(async () => {
        await browser.get(browser.baseUrl);
        await(await homePage.Header.CareersButton).click();
    });

    beforeEach(async () => {
        await browser.manage().deleteAllCookies();
          });


    describe("Careers page header check", () => {

               
        it(`verify that Careers Page url is equal to the ${browser.baseUrl+"careers/"}`, async () => {
            const url = await browser.getCurrentUrl();

            return expect(url).toEqual(browser.baseUrl+"careers/");
        });
        
        it(`Careers page title`, async () => {

            await browser.actions({ bridge:true}).mouseMove(careersPage.Page).perform();
            await browser.sleep(2000);

            const careerTitle = await browser.getTitle();

            return expect(careerTitle).toEqual('Accelerate Your Career with a Global IT Company | Exadel');          
            

        });

        it(`All Locations presents`, async () => {

            await browser.actions({ bridge:true}).mouseMove(careersPage.AllLocations).perform();
            await browser.sleep(2000);

                      
            return expect(careersPage.AllLocations.getText()).toContain("All Locations");

        });

        it(`Any Speciality presents`, async () => {
            

            await browser.actions({ bridge:true}).mouseMove(careersPage.AnySpecialty).perform();
            await browser.sleep(2000);

                                
            return expect(careersPage.AnySpecialty.getText()).toContain("Any Specialty");

        });
       
       
    });
});




