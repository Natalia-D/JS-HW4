# How to run

* `npm run update`
* `npm run pre-e2e`
* `npm run e2e -- --spec "smoke/home_page_spec.js"` OR `npm run e2e` (that command will run all tests)



